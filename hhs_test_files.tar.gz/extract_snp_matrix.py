#!/usr/bin/env python3

import numpy as np
from subprocess import Popen, PIPE
import pandas as pd
import sys


def parse_line(line, pos_array, gt_array, rownumber):
    line = line.strip().split()
    pos_array[rownumber] = line[1]
    for i, GT in enumerate(line[9:]):
        gt = GT.split(':')[0]
        if gt == '0/0':
            continue
        elif gt == '1/1' or gt == '2/2' or gt == '3/3':
            gt_array[rownumber, i] = 1
        else:
            gt_array[rownumber, i] = np.nan


vcf = sys.argv[1]
outfile = sys.argv[2]

p_grep = Popen(f'grep -v ^# {vcf}'.split(), stdout=PIPE)
p_wc = Popen('wc -l'.split(), stdin=p_grep.stdout, stdout=PIPE)


with open(vcf, 'r') as file:
    counter = 0
    line = file.readline()
    while line.startswith('#'):
        old_line = line
        line = file.readline()
    else:
        # end of header reached, last line holds all column + sample names
        samples = old_line.strip().split()[9:]
        # with open(f'samples.txt', 'w') as samplefile:
        #     samplefile.write('\n'.join(samples))
    variant_number = int(p_wc.communicate()[0])

    print(
        f'header processed - {len(samples)} samples and {variant_number} variants')

    gt_array = np.zeros((variant_number, len(samples)))
    pos_array = np.empty(variant_number, dtype=int)
    while line:
        parse_line(line, pos_array, gt_array, counter)
        counter += 1
        if counter % 1000 == 0:
            print(f'variant: {counter}')
        line = file.readline()


df = pd.DataFrame(gt_array.T, index=samples, columns=pos_array)
print('writing to file...')
df.to_csv(outfile)
